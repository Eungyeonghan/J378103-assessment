﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConverterApp

{
    public partial class frm_Main : Form
    {
       
        public frm_Main()
        {
            InitializeComponent();
        
        }

       
        double dbl_UofM1; //Declaration of dbl_UofM1
        double[] arrayUofM = new double[5]; //Declaration of arrayUofM(This is array)
        int cnt = 0; //Declataration of cnt
        

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        } //If you click the Exit button application can be exit.

        private void btn_CM_to_Inches_Click(object sender, EventArgs e) //If you click the button, the program descibed blow is executed.
        {

            const double CM_TO_INCH = 0.3937; //Declare how many inches is 1cm. I use this one to convert cm to inch.

            if (!double.TryParse(txt_UnitOfMeasure1.Text, out dbl_UofM1)) //if you put not double input, you can get this.
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                txt_UnitOfMeasure1.Clear();
                txt_UnitOfMeasure1.Focus();
                listBox1.Items.Clear();
                
            } //end if

            else
            {
                if (cnt < 5) //if Condition 'cnt<5' is met, the loop execute. 
                {
                    arrayUofM[cnt] = dbl_UofM1 * CM_TO_INCH; //Put converted value into arrayUofM 
                    listBox1.Items.Clear(); //list box is cleared.
                    cnt++; //value of cnt plus 1 
                    
                    for (int i = 0; i < cnt; i++) //if condition is met, you get value from array into listbox
                    {
                        listBox1.Items.Add(arrayUofM[i]);

                    } //end for loop
                } //End if loop
                else //if Condition is not met, you see the messagebox described below.
                {
                    MessageBox.Show("error");
                }// End else

            } //end else
        } 




        private void btn_cl_to_Fah_Click(object sender, EventArgs e) //If you click the button, the program descibed blow is executed.
        {
            const double Cl_TO_Fah = 1.8; //Declare how many Farhrenheit is 1Celsius. I use this one to convert celcius to fahrenheit.

            if (!double.TryParse(txt_UnitOfMeasure1.Text, out dbl_UofM1)) //if you put not double input, you can get this.
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                txt_UnitOfMeasure1.Clear();
                txt_UnitOfMeasure1.Focus();
                listBox1.Items.Clear();

            } //end if
            else
            {
                if (cnt < 5) //if Condition 'cnt<5' is met, the loop execute.
                {
                    arrayUofM[cnt] = dbl_UofM1 * Cl_TO_Fah+32; //Put converted value into arrayUofM
                    listBox1.Items.Clear();  //list box is cleared.
                    cnt++; //value of cnt plus 1 

                    for (int i = 0; i < cnt; i++) //if condition is met, you get value from array into listbox
                    {
                        listBox1.Items.Add(arrayUofM[i]);
                    } //end for loop
                } //End if loop
                else //if Condition is not met, you see the messagebox described below.
                {
                    MessageBox.Show("error");
                }// End else
            } // End else
        }

        private void btn_cm_to_Feet_Click(object sender, EventArgs e) //If you click the button, the program descibed blow is executed.
        {
            const double cm_to_feet = 0.0328; //Declare how many feet is 1cm. I use this one to convert cm to feet.

            // validate user entry and convert to a double

            if (!double.TryParse(txt_UnitOfMeasure1.Text, out dbl_UofM1)) //if you put not double input, you can get this.
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                txt_UnitOfMeasure1.Clear();
                txt_UnitOfMeasure1.Focus();
                listBox1.Items.Clear();

            } //end if
            else
            {
              if (cnt < 5) //if Condition 'cnt<5' is met, the loop execute.
                {
                arrayUofM[cnt] = dbl_UofM1 * cm_to_feet; //Put converted value into arrayUofM
                    listBox1.Items.Clear();  //list box is cleared.
                    cnt++; //value of cnt plus 1 

                    for (int i = 0; i < cnt; i++) //if condition is met, you get value from array into listbox
                    {
                    listBox1.Items.Add(arrayUofM[i]);
                    } //end for loop

                } //End if loop
                else //if Condition is not met, you see the messagebox described below.
                {
                MessageBox.Show("error");
                }// End else
            }// End else
        }

        private void btn_km_to_miles_Click(object sender, EventArgs e) //If you click the button, the program descibed blow is executed.
        {
            const double km_to_mile = 0.6213; //Declare how many mile is 1km. I use this one to convert km to mile.


            if (!double.TryParse(txt_UnitOfMeasure1.Text, out dbl_UofM1)) //if you put not double input, you can get this.
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                txt_UnitOfMeasure1.Clear();
                txt_UnitOfMeasure1.Focus();
                listBox1.Items.Clear();

            } //end if
            else
            {
                if(cnt<5) //if Condition 'cnt<5' is met, the loop execute.
                {
                
                arrayUofM[cnt] = dbl_UofM1 * km_to_mile; //Put converted value into arrayUofM
                    listBox1.Items.Clear();  //list box is cleared.
                    cnt++; //value of cnt plus 1 

                    for (int i = 0; i < cnt; i++) //if condition is met, you get value from array into listbox
                    {
                    listBox1.Items.Add( arrayUofM[i]);
                    } //end for loop
                } //End if loop
                else //if Condition is not met, you see the messagebox described below.
                {
                 MessageBox.Show("error");
                }// End else

            }// End else
        }

        private void frm_Main_Load(object sender, EventArgs e) 
        {

        }

        private void btn_M_to_Feet_Click(object sender, EventArgs e) //If you click the button, the program descibed blow is executed.
        {
            const double METER_TO_FEET = 3.2808; //Declare how many feet is 1meter. I use this one to convert meter to feet.

            // validate user entry and convert to a double

            if (!double.TryParse(txt_UnitOfMeasure1.Text, out dbl_UofM1)) //if you put not double input, you can get this.
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                txt_UnitOfMeasure1.Clear();
                txt_UnitOfMeasure1.Focus();
                listBox1.Items.Clear();

            } //end if
            else
            {
                if (cnt < 5) //if Condition 'cnt<5' is met, the loop execute.
                {
                    arrayUofM[cnt] = dbl_UofM1 * METER_TO_FEET; //Put converted value into arrayUofM
                    listBox1.Items.Clear();  //list box is cleared.
                    cnt++; //value of cnt plus 1 

                    for (int i = 0; i < cnt; i++) //if condition is met, you get value from array into listbox
                    {
                        listBox1.Items.Add(arrayUofM[i]);
                    } //end for loop
                } //End if loop
                else //if Condition is not met, you see the messagebox described below.
                {
                    MessageBox.Show("error");
                }// End else
            }// End else
        }
    } //end form
} //end converterapp
